gcc -Wall -o balance balance.c -lm -I ./include
gcc -Wall -o fisher fisher.c -lm -I ./include
gcc -Wall -o tree tree.c -lm -I ./include
